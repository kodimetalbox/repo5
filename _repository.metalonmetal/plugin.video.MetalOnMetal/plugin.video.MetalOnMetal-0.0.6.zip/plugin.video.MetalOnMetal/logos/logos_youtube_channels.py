def youtube_channels(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3dOGT6ZqPuhDvtgme1Y3_XsvLSe5xGJwN1sRYpahcmgvEEmaJ-CzpVWVKNFRqGdKLymtkr51jwNUDMSKdZQtS59SG9ZUqS80pZK3vgcz_puYmb0OBMyLK1bF1uhoICaFqfH4Dt6UpHqlJ_E_zcscwWu=s512-no"
    
def shauntrack(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3fPuwkJDGWi-GwDzu1iYUY586hYPD7MSp1Hu6aRsvHTuKaNFr8hznPZZkVwOh0bBTjWkLnPsQC5r0dH6NjhUmEOy5gUlgQKISMKJ6nuxnRWVHYdNq2Uq9V2UuTE1bFJZvSDFRDJiaS-MEUB00eU7dHY=w1280-h720-no"
    
def amusia(params):
    return "https://lh3.googleusercontent.com/pw/ACtC-3epAJU3lmNv4n9682IqGp1zAdEE3C5ZxwWvzCkgrI4gYOMc2sEQHI_OGtG2nvhpmSmvZT-CUDyLDhu0SjcLuT_QDKxhd-fH0cFHoeJgt5HlEncpW1k9BrbjEi794Cik7c5Sh8Eyn-BdfacggveMabDF=w575-h286-no?authuser=0"
